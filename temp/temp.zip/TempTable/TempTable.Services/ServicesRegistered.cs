﻿using Microsoft.Extensions.DependencyInjection;
using System.Reflection;

namespace {{.ProjectName}}.Services
{
    public static class ServicesRegistered
    {
        public static IServiceCollection AddServices(this IServiceCollection service)
        {
            var serviceTypes = Assembly.GetExecutingAssembly().GetTypes().Where(t => t.Name.EndsWith("Service")).ToList();
            serviceTypes.ForEach(t => service.AddSingleton(t));
            return service;
        }
    }
}
