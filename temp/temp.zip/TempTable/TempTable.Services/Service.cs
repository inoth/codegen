﻿using Microsoft.EntityFrameworkCore;
using {{.ProjectName}}.DB.Models;
using {{.ProjectName}}.Entity;
using {{.ProjectName}}.Entity.Request.{{.TableName}};
using {{.ProjectName}}.Tools;

namespace {{.ProjectName}}.Services
{
    public class {{.TableName}}Service
    {
        private readonly IDbContextFactory<{{.DbName}}Context> _contextFactory;
        private readonly ResponseMessage _res;
        public {{.TableName}}Service(IDbContextFactory<{{.DbName}}Context> contextFactory,
            ResponseMessage res)
        {
            _contextFactory = contextFactory;
            _res = res;
        }

        public async Task<ResponseMessage> Get{{.TableName}}sAsync()
        {
            using var _context = _contextFactory.CreateDbContext();

            var result = await _context.{{.TableName}}
                .Where(e => e.IsDelete == 0).ToListAsync();

            _res.data = result;
            return _res;
        }

        public async Task<ResponseMessage> Get{{.TableName}}sByPageAsync(int pageIndex, int pageSize)
        {
            using var _context = _contextFactory.CreateDbContext();

            var query = _context.{{.TableName}}
                .Where(e => e.IsDelete == 0);

            var result = await query.GetPaged(pageIndex, pageSize).ToListAsync();

            _res.data = result;
            return _res;
        }

    

        public async Task<ResponseMessage> Get{{.TableName}}Async({{range .PKList}} {{.Type}} {{.Field}}, {{end}} bool ignore = true)
        {
            using var _context = _contextFactory.CreateDbContext();

            var res = await _context.{{.TableName}}s.FirstAsync(p => 
                {{range .PKList}} p.{{.Field}} == {{.Field}} && {{end}}
                p.IsDelete == 0);

            _res.data = res;
            return _res;
        }

        public async Task<ResponseMessage> Create{{.TableName}}Async({{.TableName}}Request postData)
        {
            using var _context = _contextFactory.CreateDbContext();
            int changes = 0;
            if ({{range .PKList}} {{.Field}} > 0 && {{end}} 1==1)
            {
                var res = await _context.{{.TableName}}s.FirstAsync(p => 
                    {{range .PKList}} p.{{.Field}} == {{.Field}} && {{end}}
                    1==1);

                {{- range .Fields}}
                res.{{.Field}} = postData.{{.Field}};
                {{- end}} 

                _context.Update(res);

                changes = await _context.SaveChangesAsync();
            }
            else
            {
                {{.TableName}} res = new() { 
                {{- range .Fields}}
                {{.Field}} = postData.{{.Field}},
                {{- end}}};

                _context.Add(res);

                changes = await _context.SaveChangesAsync();

            }
            _res.data = changes;
            return _res;
        }

        public async Task<ResponseMessage> Delete{{.TableName}}Async({{range .PKList}} {{.Type}} {{.Field}}, {{end}}bool ignore = true)
        {
            using var _context = _contextFactory.CreateDbContext();
            var res = await _context.{{.TableName}}s.FirstAsync(p => 
            {{range .PKList}} p.{{.Field}} == {{.Field}} && {{end}}
            1==1);
            
            res.IsDelete = 1;
            _context.Update(res);

            _res.data = await _context.SaveChangesAsync();
            return _res;
        }
    }
}
