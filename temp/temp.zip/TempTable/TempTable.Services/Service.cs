﻿using Microsoft.EntityFrameworkCore;
using {{.ProjectName}}.DB.Models;
using {{.ProjectName}}.Entity;
using {{.ProjectName}}.Entity.Request.{{.TableName}};
using {{.ProjectName}}.Tools;

namespace {{.ProjectName}}.Services
{
    public class {{.TableName}}Service
    {
        private readonly IDbContextFactory<{{.TableName}}Context> _contextFactory;
        private readonly ResponseMessage _res;
        public {{.TableName}}Service(IDbContextFactory<{{.DbName}}Context> contextFactory,
            ResponseMessage res)
        {
            _contextFactory = contextFactory;
            _res = res;
        }

        public async Task<ResponseMessage> Get{{.TableName}}Async()
        {
            using var _context = _contextFactory.CreateDbContext();

            var result = await _context.{{.TableName}}
                .Where(account => account.IsDelete == 0).ToListAsync();

            _res.data = result;
            return _res;
        }

        public async Task<ResponseMessage> Get{{.TableName}}sByPageAsync(int pageIndex, int pageSize)
        {
            using var _context = _contextFactory.CreateDbContext();

            var query = _context.{{.TableName}}
                .Where(account => account.IsDelete == 0);

            var result = await query.GetPaged(pageIndex, pageSize).ToListAsync();

            _res.data = result;
            return _res;
        }

        public async Task<ResponseMessage> Get{{.TableName}}Async(int id)
        {
            using var _context = _contextFactory.CreateDbContext();

            var res = await _context.{{.TableName}}s.FirstAsync(p => p.Id == id && p.IsDelete == 0);

            _res.data = res;
            return _res;
        }

        public async Task<ResponseMessage> Create{{.TableName}}Async({{.TableName}}Request postData)
        {
            using var _context = _contextFactory.CreateDbContext();
            int changes = 0;
            if (postData.AccountId > 0)
            {
                var res = await _context.{{.TableName}}s.FirstAsync(p => p.Id == postData.AccountId);
                res.MobilePhone = postData.MobilePhone;
                _context.Update(res);

                changes = await _context.SaveChangesAsync();
            }
            else
            {
                {{.TableName}} res = new() { MobilePhone = postData.MobilePhone };
                _context.Add(res);

                changes = await _context.SaveChangesAsync();

            }
            _res.data = changes;
            return _res;
        }

        public async Task<ResponseMessage> Delete{{.TableName}}Async(int id)
        {
            using var _context = _contextFactory.CreateDbContext();
            var res = await _context.{{.TableName}}s.FirstAsync(p => p.Id == id);
            res.IsDelete = 1;
            _context.Update(res);

            _res.data = await _context.SaveChangesAsync();
            return _res;
        }
    }
}
