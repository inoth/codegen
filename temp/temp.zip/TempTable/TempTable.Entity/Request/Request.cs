﻿using System.ComponentModel.DataAnnotations;

namespace {{.ProjectName}}.Entity.Request.{{.TableName}}
{
    public class {{.TableName}}Request
    {
        // [Required]
        {{- range .Fields}}
        // {{.Desc}}
        public {{.Type}} {{.Field}} {get;set;}
        {{end}} 
    }
}
