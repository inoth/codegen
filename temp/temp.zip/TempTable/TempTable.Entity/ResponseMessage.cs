﻿namespace {{.ProjectName}}.Entity
{
    public class ResponseMessage
    {
        public ResponseMessage()
        {
            this.errno = 200;
            this.errmsg = "success";
        }
        public ResponseMessage(int errno, string msg, dynamic data)
        {

            this.errno = errno;
            this.errmsg = msg;
            this.data = data;
        }
        public ResponseMessage(dynamic data)
        {
            this.errno = 200;
            this.errmsg = "success";
            this.data = data;
        }
        /// <summary>
        /// 错误代码  0是 正常 其他是失败
        /// </summary>
        public int errno { get; set; }
        /// <summary>
        /// 错误信息 
        /// </summary>

        public string errmsg { get; set; }
        /// <summary>
        /// 当请求正常时候返回的数据
        /// </summary>

        public dynamic data { get; set; }
    }

    public class UserChain
    {
        public int Uid { get; set; }
        public string Name { get; set; }
        public string RealName { get; set; }
        public int Level { get; set; }
        public string Mobile { get; set; }
        public string Title { get; set; }
        public string Avatar { get; set; }
        public DateTime CreateTime { get; set; }
        public int RecomType { get; set; }

    }
}
