using Microsoft.EntityFrameworkCore;
using {{.ProjectName}}.DB.Models;
using {{.ProjectName}}.Entity;
using {{.ProjectName}}.Services;
using {{.ProjectName}}.Tools;
using System.Text.Encodings.Web;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers().AddJsonOptions(options =>
{
  
    options.JsonSerializerOptions.Converters.Add(new DateTimeJsonConverter("yyyy-MM-dd HH:mm:ss"));
 
    options.JsonSerializerOptions.Converters.Add(new BoolJsonConverter());
  
    //options.JsonSerializerOptions.PropertyNamingPolicy = null;
 
    //options.JsonSerializerOptions.DictionaryKeyPolicy = null;
   
    options.JsonSerializerOptions.Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
});
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContextFactory<NcfContext>(
    o => o.UseMySql(builder.Configuration.GetConnectionString("ContextStr"),
    ServerVersion.AutoDetect(builder.Configuration.GetConnectionString("ContextStr"))));

builder.Services.AddServices();
builder.Services.AddHttpClient();
builder.Services.AddMemoryCache();
builder.Services.AddSingleton<ConfigExtensions>();
builder.Services.AddTransient<ResponseMessage>();
//builder.Services.AddTransient(context =>
//{
//    var httpContextAccessor = (IHttpContextAccessor)context.GetService(typeof(IHttpContextAccessor));
//    return httpContextAccessor.HttpContext.Request.ReadJWTCookie();
//});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
