using Microsoft.AspNetCore.Mvc;
using {{.ProjectName}}.Entity.Request.{{.TableName}};
using {{.ProjectName}}.Services;
using System.ComponentModel.DataAnnotations;

namespace {{.ProjectName}}.Controllers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class {{.TableName}}Controller : ControllerBase
    {

        private readonly {{.TableName}}Service _service;
        public {{.TableName}}Controller({{.TableName}}Service service)
        {
            _service = service;
        }

        /// <summary>
        /// ��ѯ������ҳ��
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> Get{{.TableName}}sAsync()
        {
            return Ok(await _service.Get{{.TableName}}sAsync());
        }

        /// <summary>
        /// ��ѯ����ҳ��
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="pagseSize"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> Get{{.TableName}}sByPageAsync(int pageIndex = 1, int pagseSize = 20)
        {
            return Ok(await _service.Get{{.TableName}}sByPageAsync(pageIndex, pagseSize));
        }

        /// <summary>
        /// �鵥��
        /// </summary>
        /// <param name="accountId"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> Get{{.TableName}}Async([Required] int accountId)
        {
            return Ok(await _service.Get{{.TableName}}Async(accountId));
        }

        /// <summary>
        /// �������޸�
        /// </summary>
        /// <param name="postData"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> Create{{.TableName}}Async([FromBody] {{.TableName}}Request postData)
        {
            return Ok(await _service.Create{{.TableName}}Async(postData));
        }

        /// <summary>
        /// ɾ��
        /// </summary>
        /// <param name="accountId"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> Delete{{.TableName}}Async([Required] int accountId)
        {
            return Ok(await _service.Delete{{.TableName}}Async(accountId));
        }
    }
}