﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace {{.ProjectName}}.Tools
{
    /// <summary>
    /// 
    /// </summary>
    public static class DateTimeExtension
    {
        public static string ToWeekDay(this DateTime dateTime)
        {
            switch (dateTime.DayOfWeek)
            {
                case DayOfWeek.Monday:
                    return "星期一";

                case DayOfWeek.Tuesday:
                    return "星期二";

                case DayOfWeek.Wednesday:
                    return "星期三";

                case DayOfWeek.Thursday:
                    return "星期四";

                case DayOfWeek.Friday:
                    return "星期五";

                case DayOfWeek.Saturday:
                    return "星期六";

                case DayOfWeek.Sunday:
                    return "星期日";
                default:
                    return "";
            }

        }

        public static DateTime DBNull = Convert.ToDateTime("1900-01-01 00:00:00");
        /// <summary> 
        /// 获取时间戳 10位
        /// </summary> 
        /// <returns></returns> 
        public static long GetTimeStampTen(this DateTime dt)
        {
            return (dt.ToUniversalTime().Ticks - 621355968000000000) / 10000000;
        }


        /// <summary>
        /// 转unix时间戳
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static double ConvertToUnixTimestamp(DateTime date)
        {
            DateTime OLDtime = new DateTime(1970, 1, 1, 0, 0, 0, 0);
            TimeSpan diff = date.ToUniversalTime() - OLDtime;
            return Math.Floor(diff.TotalMilliseconds / 1000);
        }
        /// <summary>
        /// 将Unix时间戳转换为dateTime格式
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        public static DateTime UnixTimeToDateTime(int time)
        {
            if (time < 0)
                throw new ArgumentOutOfRangeException("time is out of range");

            return TimeZoneInfo.ConvertTime(new DateTime(1970, 1, 1), TimeZoneInfo.Local).AddSeconds(time);
        }

        /// 将时间戳转换为YYYY-MM-DD字符串
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        public static string UnixTimeToDateTimeYYMMDD(int time)
        {
            if (time < 0)
                throw new ArgumentOutOfRangeException("time is out of range");

            return TimeZoneInfo.ConvertTime(new DateTime(1970, 1, 1), TimeZoneInfo.Local).AddSeconds(time).ToShortDateString();
        }

        private static readonly object _lock = new object();

        /// <summary>
        /// 生成随即订单号
        /// </summary>
        /// <returns></returns>
        public static string GenerateOrderNumber()
        {
            lock (_lock)
            {
                Random ran = new Random();
                return DateTime.Now.ToString("yyyyMMddHHmmssfff") + ran.Next(100, 999).ToString();
            }
        }
        public static DateTime DateTimeParseExact(this string str)
        {
            return DateTime.ParseExact(str, "yyyyMMddHHmm", System.Globalization.CultureInfo.CurrentCulture);
        }
        public static DateTime DateParseExact(this string str)
        {
            return DateTime.ParseExact(str, "yyyyMMdd", System.Globalization.CultureInfo.CurrentCulture);
        }
        public static string MinuteToHour(this int minute)
        {
            if (minute == 0)
                return "";
            var houre = Math.Round((double)(minute / 60));
            var mm = minute % 60;
            return $"{houre}h{mm}m";
        }
        public static int CalcMinute(this DateTime a, DateTime b)
        {
            TimeSpan ts = a - b;
            int n = ts.Minutes;//分差bai
            var m = ts.TotalMinutes;//总时du间zhi分差
            return (int)m;
        }
        public static int CalcMinuteForAir(this DateTime a, DateTime b)
        {
            if (a < b)
            {
                a = a.AddDays(1);
            }
            TimeSpan ts = a - b;
            int n = ts.Minutes;//分差bai
            var m = ts.TotalMinutes;//总时du间zhi分差
            return (int)m;
        }
        public static string MinuteToHourTrain(this int minute)
        {
            if (minute == 0)
                return "";
            var houre = Math.Round((double)(minute / 60));
            var mm = minute % 60;
            return $"{houre}时{mm}分";
        }
    }
}
