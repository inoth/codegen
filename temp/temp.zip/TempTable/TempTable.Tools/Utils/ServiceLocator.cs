﻿using Microsoft.AspNetCore.Builder;
using System;
using System.Collections.Generic;
using System.Text;

namespace {{.ProjectName}}.Tools
{
    public static class ServiceLocator
    {
        public static IServiceProvider Instance { get; set; }
        public static IApplicationBuilder InitServiceLocator(this IApplicationBuilder builder)
        {
            ServiceLocator.Instance = builder.ApplicationServices;
            return builder;
        }
        public static void InitServiceLocator(this IServiceProvider serviceProvider)
        {
            ServiceLocator.Instance = serviceProvider;
        }
    }
}
