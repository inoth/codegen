﻿//using Microsoft.AspNetCore.Http;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;

//namespace {{.ProjectName}}.Tools
//{
//    public static class JwtTokenExtensions
//    {
//        public static GenericJwtToken ReadJWTCookie(this HttpRequest request)
//        {
//            try
//            {
//                string jwt = request.Headers["Authorization"].ToString();
//                if (string.IsNullOrWhiteSpace(jwt))
//                {
//                    request.Cookies.TryGetValue("jwt", out jwt);
//                }
//                var login = AuthJwtEncoder.Decode<GenericJwtToken>(jwt);
//                return login;
//            }
//            catch (Exception) { }
//            return new GenericJwtToken();
//        }
//        public static void WriteJWTCookie(this HttpResponse response, string token)
//        {
//            response.Cookies.Append("jwt", token, new CookieOptions()
//            {
//                HttpOnly = true,
//                Expires = DateTime.Now.AddDays(1)
//            });
//        }
//    }
//}
