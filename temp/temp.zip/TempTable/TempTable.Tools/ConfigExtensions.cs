﻿using Microsoft.Extensions.Configuration;

namespace {{.ProjectName}}.Tools
{
    /// <summary>
    /// 读取配置文件信息
    /// </summary>
    public class ConfigExtensions
    {
        private readonly IConfiguration configuration;
        public ConfigExtensions(IConfiguration configuration)
        {
            this.configuration = configuration;
        }
        public string GetConfig(string key)
        {
            return configuration[key];
        }
        public T GetConfig<T>() where T : class
        {
            Type type = typeof(T);
            return configuration.GetSection(type.Name).Get<T>();
        }
    }
}
