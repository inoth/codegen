﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace {{.ProjectName}}.DB.Models
{
    public partial class {{.DbName}}Context : DbContext
    {
        public {{.DbName}}Context()
        {
        }

        public {{.DbName}}Context(DbContextOptions<{{.DbName}}Context> options)
            : base(options)
        {
        }
        
        {{- range $item := .Tables}}
        public virtual DbSet<{{$item}}> {{$item}}s {get;set;} = null!;
        {{- end}} 

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

        }
    }
}
