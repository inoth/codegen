﻿using System.ComponentModel.DataAnnotations;

namespace {{.ProjectName}}.DB.Models
{
    public partial class {{.TableName}}
    {
        // [Required]
        {{- range .Fields}}
        // {{.Desc}}
        public {{.Type}} {{.Field}} {get;set;}
        {{end}} 
    }
}
